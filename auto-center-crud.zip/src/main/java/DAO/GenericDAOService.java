package DAO;

/**
 *
 * @author danielp6r
 */
public class GenericDAOService {

}
